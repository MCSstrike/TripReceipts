# Trip Receipts — Android

A small **offline-native Android receipt and travel expense tracker**. There is no login, cloud service, automatic currency conversion, advertising, or analytics.

## Features

- Create as many trips as you need, setting a default local currency code (EUR, USD, JPY, etc.).
- When adding each receipt, choose **Take a photo**, **Choose from gallery** or **Skip picture**.
- Enter **place**, **expense type**, **local currency code**, **local amount**, **GBP amount**, **date**, and optional notes.
- GBP and local amounts are completely independent manual fields. They are **never converted**.
- Browse and edit saved receipts, change/remove photos, and delete entries.
- Every receipt has a stable number (`01`, `02`, `03`…), which does not change if another entry is deleted.
- End a trip, generating an export ZIP. Completed trips remain accessible and can be reopened and exported again.
- **Save ZIP** uses Android's document picker; **Share** uses Android's share sheet, including installed email apps.

## Export structure

For a trip named `Business trip`, the exported ZIP looks like:

```text
Business_trip_2026-11-22_....zip
├── Expenses_Business_trip.xlsx
├── README.txt
└── receipts/
    ├── 01-IMG_0500.jpg
    ├── 02-receipt.png
    └── 04-hotel.jpg
```

The `.xlsx` workbook contains:

- **Expenses**: `Ref`, `Date`, `Place`, `Type`, `Local currency`, `Local amount`, `GBP amount`, `Receipt image`, `Notes`; filterable headers, frozen columns header row, GBP totals and clickable links to receipt images after the ZIP is extracted.
- **Summary**: receipt count, total GBP, GBP totals by expense type, and separate totals for each local currency. These summaries use Excel formulas, with cached totals for other spreadsheet readers.

Receipt **03** in this example has no photo, so there is no `03-...` file; its workbook entry still exists. Only image **copies inside the ZIP** are renamed. Private originals remain available for later edits and fresh exports.

**Unzip the archive before opening Excel** so its relative links to the `receipts` directory resolve correctly. No exchange rates are looked up or applied anywhere.

## Build and install

You need **Android Studio** (with Android SDK API 35 and JDK 17+) and internet access on your development computer for the first Gradle sync. This is a project, not a compiled APK.

1. Unzip the project folder.
2. Open the `TripReceiptsAndroid` directory in Android Studio.
3. On first setup, download the official Gradle wrapper JAR by running `./gradlew --version` (macOS/Linux) or `gradlew.bat --version` (Windows). The included launcher scripts bootstrap the official wrapper from Gradle's versioned GitHub release because no binary wrapper JAR is bundled. **Do this before Gradle sync if Android Studio reports a missing wrapper JAR.**
4. Allow Android Studio to install the requested Android SDK, sync Gradle, and select **Run** on a connected Android phone (USB debugging enabled) or emulator.
5. To create a standalone installable debug APK, run `./gradlew assembleDebug` (or `gradlew.bat assembleDebug`). The output is `app/build/outputs/apk/debug/app-debug.apk`. Transfer and install it on the phone.

For a release APK, configure your own Android signing key and release signing configuration.

## Technical details

- Package: `uk.layerworks.tripreceipts`
- Kotlin, one Android Activity, standard Android UI widgets. No third-party runtime libraries.
- Android 8.0+ (`minSdk 26`); `compileSdk`/`targetSdk` 35.
- JSON database: app-private `filesDir/trips.json`.
- Photos: app-private `filesDir/images/`. Gallery imports are copied locally immediately.
- Exports: app-private `filesDir/exports/` and exported via the system Storage Access Framework or a URI-permission-protected `ContentProvider`.
- Excel and ZIP: Java `ZipOutputStream` + OOXML spreadsheet parts, avoiding external Excel/ZIP dependencies.
- No internet/network or storage permissions required. Camera app access is handled by a temporary granted content URI.

### Note on privacy and backups

Trip data stays on this device. Uninstalling the app deletes its private photos and database; saved/shared ZIP exports are unaffected. Keep external copies of your completed trips. This app currently supports one image per receipt and does not synchronise data across devices.

### Current limitations

- No APK is included in the supplied source ZIP (Android SDK/build tools were unavailable in the creation environment).
- The app does not yet support multiple photos per expense, OCR, currency conversion, or cloud syncing.
- Unsaved form changes are not retained after Android terminates the editing Activity during a low-memory event.
