package uk.layerworks.tripreceipts

import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.math.BigDecimal
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** No external Excel library is required: creates a standards-compliant OOXML .xlsx. */
data class ExportRow(
    val ref: String,
    val date: String,
    val place: String,
    val category: String,
    val currency: String,
    val local: BigDecimal,
    val gbp: BigDecimal,
    val imageName: String,
    val notes: String,
    val imagePath: String
)

object TripExporter {
    fun export(trip: Trip, exportDir: File): File {
        exportDir.mkdirs()
        val safeTitle = safeName(trip.title).take(48).ifBlank { "Trip" }
        val rows = trip.receipts.sortedBy { it.sequence }.map { r ->
            val name = if (r.imagePath.isNotBlank() && File(r.imagePath).isFile) {
                val original = r.originalImageName.ifBlank { File(r.imagePath).name }
                "${r.ref}-${safeImageName(original)}"
            } else ""
            ExportRow(r.ref, r.date, r.place, r.category, r.localCode,
                r.localValue(), r.gbpValue(), name, r.notes, r.imagePath)
        }
        val xlsxName = "Expenses_${safeTitle}.xlsx"
        val zipFile = File(exportDir, "${safeTitle}_${LocalDate.now()}_${System.currentTimeMillis()}.zip")
        val xlsx = ByteArrayOutputStream()
        ExcelWorkbook.write(trip.title, trip.endedAt != null, rows, xlsx)
        ZipOutputStream(FileOutputStream(zipFile)).use { zip ->
            add(zip, xlsxName, xlsx.toByteArray())
            add(zip, "receipts/", ByteArray(0))
            rows.forEach { r ->
                if (r.imageName.isNotBlank()) {
                    zip.putNextEntry(ZipEntry("receipts/${r.imageName}"))
                    File(r.imagePath).inputStream().use { it.copyTo(zip) }
                    zip.closeEntry()
                }
            }
            val readme = """
                Trip Receipts export
                ====================
                Trip: ${trip.title}
                Receipts: ${rows.size}
                Workbook: $xlsxName

                The Ref column (01, 02, 03...) matches the prefix on each image
                inside receipts/. Entries without an image still have a reference.

                Extract the ZIP before opening the Excel workbook to allow its
                receipt image hyperlinks to work as relative file links.

                IMPORTANT: Local currency and GBP amounts are manually entered.
                There is NO automatic currency conversion or exchange-rate lookup.
            """.trimIndent() + "\n"
            add(zip, "README.txt", readme.toByteArray(Charsets.UTF_8))
        }
        return zipFile
    }

    private fun safeImageName(value: String): String {
        val cleaned = safeName(value)
        val ext = cleaned.substringAfterLast('.', "").take(6)
        val stem = if (ext.isNotEmpty() && cleaned.contains('.'))
            cleaned.substringBeforeLast('.') else cleaned
        return stem.take(65).ifBlank { "receipt" } + if (ext.isNotEmpty()) ".$ext" else ".jpg"
    }

    private fun safeName(value: String): String {
        val base = File(value.replace('\\', '/')).name
        val normalized = base.replace(Regex("[^A-Za-z0-9._-]"), "_")
            .trim('.', '_', '-').ifBlank { "receipt.jpg" }
        return normalized
    }

    private fun add(zip: ZipOutputStream, name: String, data: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(data)
        zip.closeEntry()
    }
}

private object ExcelWorkbook {
    private val ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private fun x(s: String): String = s.replace("&", "&amp;")
        .replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")
        .filter { it == '\t' || it == '\n' || it == '\r' || it.code >= 32 }
    private fun inline(cell: String, value: String, style: Int = 0): String =
        "<c r=\"$cell\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${x(value)}</t></is></c>"
    private fun num(cell: String, value: BigDecimal, style: Int = 3): String =
        "<c r=\"$cell\" s=\"$style\"><v>${value.toPlainString()}</v></c>"
    private fun formula(cell: String, code: String, cached: BigDecimal, style: Int = 3): String =
        "<c r=\"$cell\" s=\"$style\"><f>${x(code)}</f><v>${cached.toPlainString()}</v></c>"
    private fun hyperlink(cell: String, path: String, ref: String, style: Int): String {
        val f = "HYPERLINK(\"${quoteFormula(path)}\",\"Open $ref\")"
        return "<c r=\"$cell\" s=\"$style\" t=\"str\"><f>${x(f)}</f><v>Open ${x(ref)}</v></c>"
    }
    private fun line(number: Int, cells: String, height: Int? = null): String =
        "<row r=\"$number\"${if (height != null) " ht=\"$height\" customHeight=\"1\"" else ""}>$cells</row>"
    private fun quoteFormula(s: String) = s.replace("\"", "\"\"")

    fun write(title: String, ended: Boolean, rows: List<ExportRow>, output: ByteArrayOutputStream) {
        ZipOutputStream(output).use { z ->
            put(z, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
                <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
                <Default Extension="xml" ContentType="application/xml"/>
                <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
                <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
                <Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
                <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
                </Types>""".trimIndent())
            put(z, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
                </Relationships>""".trimIndent())
            put(z, "xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8"?>
                <workbook xmlns="$ns" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
                <sheets><sheet name="Expenses" sheetId="1" r:id="rId1"/>
                <sheet name="Summary" sheetId="2" r:id="rId2"/></sheets>
                <calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>""".trimIndent())
            put(z, "xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8"?>
                <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
                <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
                <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/>
                <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
                </Relationships>""".trimIndent())
            put(z, "xl/styles.xml", styles())
            put(z, "xl/worksheets/sheet1.xml", expensesSheet(title, rows))
            put(z, "xl/worksheets/sheet2.xml", summarySheet(title, ended, rows))
        }
    }

    private fun put(z: ZipOutputStream, name: String, content: String) {
        z.putNextEntry(ZipEntry(name))
        z.write(content.toByteArray(Charsets.UTF_8))
        z.closeEntry()
    }

    private fun styles(): String = """<?xml version="1.0" encoding="UTF-8"?>
        <styleSheet xmlns="$ns">
        <numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00##;[Red](#,##0.00##)"/></numFmts>
        <fonts count="4">
        <font><sz val="11"/><color rgb="FF17273D"/><name val="Aptos"/></font>
        <font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font>
        <font><b/><sz val="11"/><color rgb="FF17273D"/><name val="Aptos"/></font>
        <font><b/><sz val="11"/><color rgb="FF237D87"/><name val="Aptos"/></font>
        </fonts>
        <fills count="5"><fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF17273D"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFF0F5F7"/><bgColor indexed="64"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFE4F5F2"/><bgColor indexed="64"/></patternFill></fill>
        </fills>
        <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
        <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
        <cellXfs count="9">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/>
        <xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
        <xf numFmtId="0" fontId="3" fillId="4" borderId="0" xfId="0" applyFill="1"/>
        <xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1"/>
        <xf numFmtId="164" fontId="0" fillId="3" borderId="0" xfId="0" applyFill="1" applyNumberFormat="1"/>
        <xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFill="1"/>
        <xf numFmtId="164" fontId="2" fillId="4" borderId="0" xfId="0" applyFill="1" applyNumberFormat="1"/>
        </cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
        </styleSheet>""".trimIndent()

    private fun expensesSheet(title: String, rows: List<ExportRow>): String {
        val sb = StringBuilder()
        val first = 6
        val last = 5 + rows.size
        val total = rows.fold(BigDecimal.ZERO) { acc, it -> acc + it.gbp }
        sb.append(line(1, inline("A1", "TRIP RECEIPTS  /  $title", 1), 36))
        sb.append(line(2, inline("A2", "Manual currency entries • Receipt references match image prefixes", 4), 23))
        sb.append(line(3, inline("F3", "TOTAL GBP", 7) + num("G3", total, 8), 24))
        sb.append(line(4, "", 10))
        val headers = listOf("Ref", "Date", "Place", "Type", "Local currency", "Local amount", "GBP amount", "Receipt image", "Notes")
        sb.append(line(5, headers.mapIndexed { i, header -> inline("${'A' + i}5", header, 2) }.joinToString(""), 27))
        rows.forEachIndexed { i, r ->
            val rn = first + i
            val alt = i % 2 == 1
            val textStyle = if (alt) 5 else 0
            val moneyStyle = if (alt) 6 else 3
            var cs = inline("A$rn", r.ref, 4)
            cs += inline("B$rn", r.date, textStyle)
            cs += inline("C$rn", r.place, textStyle)
            cs += inline("D$rn", r.category, textStyle)
            cs += inline("E$rn", r.currency, textStyle)
            cs += num("F$rn", r.local, moneyStyle)
            cs += num("G$rn", r.gbp, moneyStyle)
            if (r.imageName.isNotBlank()) {
                val path = "receipts/${r.imageName}"
                cs += hyperlink("H$rn", path, r.ref, textStyle)
            } else cs += inline("H$rn", "—", textStyle)
            cs += inline("I$rn", r.notes, textStyle)
            sb.append(line(rn, cs, 23))
        }
        val tr = last + 2
        val totalCell = if (rows.isEmpty()) num("G$tr", BigDecimal.ZERO, 8)
            else formula("G$tr", "SUM(G$first:G$last)", total, 8)
        sb.append(line(tr, inline("F$tr", "TOTAL GBP", 7) + totalCell, 28))
        val lastAuto = maxOf(5, last)
        return """<?xml version="1.0" encoding="UTF-8"?>
            <worksheet xmlns="$ns">
            <dimension ref="A1:I$tr"/>
            <sheetViews><sheetView workbookViewId="0"><pane ySplit="5" topLeftCell="A6" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
            <sheetFormatPr defaultRowHeight="20"/>
            <cols><col min="1" max="1" width="9" customWidth="1"/>
            <col min="2" max="2" width="15" customWidth="1"/>
            <col min="3" max="3" width="29" customWidth="1"/>
            <col min="4" max="4" width="24" customWidth="1"/>
            <col min="5" max="5" width="19" customWidth="1"/>
            <col min="6" max="7" width="18" customWidth="1"/>
            <col min="8" max="8" width="24" customWidth="1"/>
            <col min="9" max="9" width="36" customWidth="1"/></cols>
            <sheetData>$sb</sheetData>
            <mergeCells count="2"><mergeCell ref="A1:I1"/><mergeCell ref="A2:I2"/></mergeCells>
            <autoFilter ref="A5:I$lastAuto"/>
            <pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>
            </worksheet>""".trimIndent()
    }

    private fun summarySheet(title: String, ended: Boolean, rows: List<ExportRow>): String {
        val sb = StringBuilder()
        val end = 5 + rows.size
        val total = rows.fold(BigDecimal.ZERO) { a, r -> a + r.gbp }
        sb.append(line(1, inline("A1", "TRIP SUMMARY  /  $title", 1), 36))
        sb.append(line(3, inline("A3", "Status", 7) + inline("B3", if (ended) "Completed" else "In progress"), 24))
        sb.append(line(4, inline("A4", "Receipt count", 7) + num("B4", BigDecimal(rows.size), 3), 24))
        val gbpFormula = if (rows.isEmpty()) num("B5", BigDecimal.ZERO, 8)
            else formula("B5", "SUM(Expenses!G6:G$end)", total, 8)
        sb.append(line(5, inline("A5", "Total spent (GBP)", 7) + gbpFormula, 26))
        sb.append(line(7, inline("A7", "GBP BY TYPE", 1) + inline("B7", "GBP total", 2), 25))
        val categories = rows.map { it.category }.distinct().sorted()
        var i = 8
        categories.forEach { category ->
            val value = rows.filter { it.category == category }.fold(BigDecimal.ZERO) { a, r -> a + r.gbp }
            val sumif = "SUMIF(Expenses!D6:D$end,\"${quoteFormula(category)}\",Expenses!G6:G$end)"
            sb.append(line(i, inline("A$i", category, if (i % 2 == 0) 5 else 0) + formula("B$i", sumif, value), 23))
            i++
        }
        i += 2
        sb.append(line(i, inline("A$i", "LOCAL CURRENCY TOTALS", 1) + inline("B$i", "Local total", 2), 25))
        i++
        val currencies = rows.map { it.currency }.distinct().sorted()
        currencies.forEach { currency ->
            val value = rows.filter { it.currency == currency }.fold(BigDecimal.ZERO) { a, r -> a + r.local }
            val sumif = "SUMIF(Expenses!E6:E$end,\"${quoteFormula(currency)}\",Expenses!F6:F$end)"
            sb.append(line(i, inline("A$i", currency, if (i % 2 == 0) 5 else 0) + formula("B$i", sumif, value), 23))
            i++
        }
        i += 2
        sb.append(line(i, inline("A$i", "Local totals are kept separate by currency. No conversion is performed."), 29))
        return """<?xml version="1.0" encoding="UTF-8"?>
            <worksheet xmlns="$ns"><dimension ref="A1:B$i"/>
            <sheetViews><sheetView workbookViewId="0"/></sheetViews>
            <cols><col min="1" max="1" width="52" customWidth="1"/><col min="2" max="2" width="24" customWidth="1"/></cols>
            <sheetData>$sb</sheetData><mergeCells count="1"><mergeCell ref="A1:B1"/></mergeCells>
            <pageMargins left="0.3" right="0.3" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>
            </worksheet>""".trimIndent()
    }
}
