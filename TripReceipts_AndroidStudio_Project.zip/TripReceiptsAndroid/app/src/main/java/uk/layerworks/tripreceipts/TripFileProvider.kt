package uk.layerworks.tripreceipts

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

/** Small private file provider for full-resolution camera photos and ZIP sharing. */
class TripFileProvider : ContentProvider() {
    companion object {
        private const val AUTHORITY = "uk.layerworks.tripreceipts.files"
        fun forFile(folder: String, filename: String): Uri = Uri.Builder()
            .scheme("content").authority(AUTHORITY)
            .appendPath(folder).appendPath(filename).build()
    }

    private fun resolve(uri: Uri): File {
        require(uri.authority == AUTHORITY) { "Wrong content authority" }
        val parts = uri.pathSegments
        require(parts.size == 2 && (parts[0] == "images" || parts[0] == "exports")) {
            "Unsupported path"
        }
        val root = File(requireNotNull(context).filesDir, parts[0]).canonicalFile
        val file = File(root, parts[1]).canonicalFile
        require(file.parentFile == root) { "Invalid path" }
        return file
    }

    override fun onCreate(): Boolean = true
    override fun getType(uri: Uri): String = when (resolve(uri).extension.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heic"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }
    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val file = resolve(uri)
        val flags = when (mode) {
            "r" -> ParcelFileDescriptor.MODE_READ_ONLY
            "w", "wt" -> ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE or ParcelFileDescriptor.MODE_WRITE_ONLY
            "rw" -> ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_READ_WRITE
            else -> throw IllegalArgumentException("Unsupported mode")
        }
        if (mode != "r") file.parentFile?.mkdirs()
        return ParcelFileDescriptor.open(file, flags)
    }
    override fun query(uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val f = resolve(uri)
        val fields = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val result = MatrixCursor(fields)
        result.addRow(fields.map {
            when (it) {
                OpenableColumns.DISPLAY_NAME -> f.name
                OpenableColumns.SIZE -> f.length()
                else -> null
            }
        })
        return result
    }
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException()
}
