package uk.layerworks.tripreceipts

import android.app.Activity
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.math.BigDecimal
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private enum class Page { TRIPS, TRIP, EDIT }
    private lateinit var store: TripStore
    private var page = Page.TRIPS
    private var tripId: String? = null
    private var receiptId: String? = null
    private var photoPath = ""
    private var originalPhotoName = ""
    private var photoPreview: ImageView? = null
    private var photoCaption: TextView? = null
    private var pendingCameraFile: File? = null
    private var pendingExportFile: File? = null
    private val dateFormat = DateTimeFormatter.ISO_LOCAL_DATE

    private val navy = Color.rgb(23, 39, 61)
    private val teal = Color.rgb(35, 125, 135)
    private val pale = Color.rgb(244, 247, 248)
    private val muted = Color.rgb(104, 117, 133)
    private val line = Color.rgb(217, 226, 230)
    private val white = Color.WHITE
    private val categories = listOf("Food & drink", "Project cost", "Travel & transport",
        "Accommodation", "Equipment & supplies", "Entertainment", "Other")

    companion object {
        private const val REQUEST_GALLERY = 201
        private const val REQUEST_CAMERA = 202
        private const val REQUEST_SAVE_ZIP = 203
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        try {
            store = TripStore(this)
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Couldn't open the database")
                .setMessage("Your saved data has not been changed. ${e.message}")
                .setPositiveButton("Close app") { _, _ -> finish() }
                .setCancelable(false).show()
            return
        }
        val oldTrip = savedInstanceState?.getString("trip_id")
        if (oldTrip != null && store.get(oldTrip) != null) renderTrip(oldTrip)
        else renderTrips()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("trip_id", tripId)
    }

    private fun dp(value: Int) = (resources.displayMetrics.density * value + 0.5f).toInt()
    private fun shape(color: Int, radius: Int = 15, border: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (border != null) setStroke(dp(1), border)
        }

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }
    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        layoutParams = LinearLayout.LayoutParams(-1, -2)
    }
    private fun tv(value: String, size: Float = 14f, color: Int = navy, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            includeFontPadding = true
        }

    private fun gap(parent: LinearLayout, h: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(h)))
    }
    private fun add(parent: LinearLayout, view: View, top: Int = 0, bottom: Int = 0,
                    left: Int = 0, right: Int = 0) {
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom))
        parent.addView(view, lp)
    }
    private fun button(title: String, primary: Boolean = true, onClick: () -> Unit): TextView =
        tv(title, 15f, if (primary) white else navy, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = RippleDrawable(ColorStateList.valueOf(0x33237D87),
                shape(if (primary) navy else white, 13, if (primary) null else line), null)
            isClickable = true
            isFocusable = true
            contentDescription = title
            setOnClickListener { onClick() }
        }

    private fun card(): LinearLayout = column().apply {
        background = shape(white, 17, line)
        setPadding(dp(17), dp(16), dp(17), dp(16))
        elevation = dp(1).toFloat()
    }

    private fun base(title: String, subtitle: String, back: (() -> Unit)?): Pair<LinearLayout, LinearLayout> {
        val root = column().apply {
            setBackgroundColor(pale)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        val header = column().apply {
            setBackgroundColor(navy)
            setPadding(dp(20), dp(15), dp(20), dp(19))
        }
        if (back != null) {
            val backLink = tv("‹  Back", 14f, 0xFFB7DFDC.toInt(), true).apply {
                setPadding(0, dp(2), 0, dp(12))
                isClickable = true
                setOnClickListener { back() }
            }
            add(header, backLink)
        }
        add(header, tv(title, 27f, white, true))
        add(header, tv(subtitle, 12f, 0xFFD0DDE3.toInt()), top = 4)
        root.addView(header)
        val scroll = ScrollView(this).apply {
            fillViewport = false
            isVerticalScrollBarEnabled = false
        }
        val body = column().apply { setPadding(dp(18), dp(20), dp(18), dp(24)) }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 35) {
            window.decorView.setOnApplyWindowInsetsListener { _, insets ->
                val bars = insets.getInsets(WindowInsets.Type.systemBars())
                root.setPadding(bars.left, bars.top, bars.right, bars.bottom)
                insets
            }
            root.requestApplyInsets()
        }
        return root to body
    }

    private fun footer(root: LinearLayout, build: (LinearLayout) -> Unit) {
        val c = column().apply {
            setBackgroundColor(white)
            setPadding(dp(18), dp(12), dp(18), dp(14))
        }
        c.addView(View(this).apply { setBackgroundColor(line) }, LinearLayout.LayoutParams(-1, dp(1)))
        gap(c, 12)
        build(c)
        root.addView(c)
    }

    private fun money(value: BigDecimal): String =
        NumberFormat.getNumberInstance(Locale.UK).apply {
            minimumFractionDigits = 2
            maximumFractionDigits = 3
        }.format(value)

    private fun renderTrips() {
        page = Page.TRIPS
        tripId = null
        receiptId = null
        val (root, body) = base("Trip Receipts", "Your expenses, organised by trip. Stored offline.", null)
        val introduction = card()
        add(introduction, tv("Keep the receipt. Skip the maths.", 19f, navy, true))
        add(introduction, tv("Attach photos, enter both amounts yourself, and export everything as one ZIP.",
            13f, muted), top = 8)
        add(body, introduction)
        gap(body, 18)
        add(body, button("+  Create a trip") { newTripDialog() })
        gap(body, 25)
        val trips = store.trips.sortedWith(compareBy<Trip> { it.endedAt != null }.thenByDescending { it.createdAt })
        if (trips.isEmpty()) {
            val empty = card()
            add(empty, tv("No trips yet", 18f, navy, true))
            add(empty, tv("Create your first trip to start collecting expenses and receipt photos.", 13f, muted), top = 7)
            add(body, empty)
        } else {
            add(body, tv("YOUR TRIPS", 11f, muted, true), bottom = 10)
            trips.forEach { trip ->
                val c = card()
                val top = row()
                val info = column()
                add(info, tv(trip.title, 18f, navy, true))
                add(info, tv(if (trip.endedAt == null) "ACTIVE TRIP" else "COMPLETED TRIP",
                    10f, if (trip.endedAt == null) teal else muted, true), top = 5)
                top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                top.addView(tv("›", 27f, muted))
                c.addView(top)
                gap(c, 14)
                add(c, tv("${trip.receipts.size} receipts   •   £${money(trip.gbpTotal())}", 14f, navy, true))
                val totals = trip.localTotals().entries.joinToString("   ·   ") { "${it.key} ${money(it.value)}" }
                if (totals.isNotEmpty()) add(c, tv(totals, 12f, muted), top = 6)
                c.isClickable = true
                c.isFocusable = true
                c.setOnClickListener { renderTrip(trip.id) }
                add(body, c, bottom = 10)
            }
        }
    }

    private fun newTripDialog() {
        val form = column().apply { setPadding(dp(22), dp(8), dp(22), dp(5)) }
        val name = entry("e.g. Berlin business trip", "", false)
        val currency = entry("EUR", "EUR", false).apply {
            filters = arrayOf(android.text.InputFilter.LengthFilter(3))
        }
        add(form, tv("TRIP NAME", 12f, muted, true), top = 8, bottom = 7)
        add(form, name)
        add(form, tv("DEFAULT LOCAL CURRENCY (ISO CODE)", 12f, muted, true), top = 18, bottom = 7)
        add(form, currency)
        AlertDialog.Builder(this)
            .setTitle("New trip")
            .setView(form)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Create", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val title = name.text.toString().trim()
                        val code = currency.text.toString().trim().uppercase(Locale.ROOT)
                        if (title.isBlank()) { name.error = "Enter a trip name"; return@setOnClickListener }
                        if (!isCurrency(code)) { currency.error = "Use a 3-letter currency code"; return@setOnClickListener }
                        val trip = Trip(title = title, defaultCurrency = code)
                        store.trips.add(trip)
                        store.save()
                        dialog.dismiss()
                        renderTrip(trip.id)
                    }
                }
                dialog.show()
            }
    }

    private fun renderTrip(id: String) {
        val trip = store.get(id) ?: run { renderTrips(); return }
        page = Page.TRIP
        tripId = id
        receiptId = null
        val (root, body) = base(trip.title, if (trip.endedAt == null) "Active trip" else "Completed trip",
            { renderTrips() })
        val stats = card()
        add(stats, tv("TOTAL ENTERED IN GBP", 11f, muted, true))
        add(stats, tv("£${money(trip.gbpTotal())}", 32f, navy, true), top = 4)
        add(stats, tv("${trip.receipts.size} receipts recorded", 13f, muted), top = 3)
        if (trip.localTotals().isNotEmpty()) {
            gap(stats, 12)
            add(stats, tv("LOCAL CURRENCY TOTALS", 11f, muted, true))
            trip.localTotals().forEach { (code, amount) ->
                add(stats, tv("$code  ${money(amount)}", 14f, teal, true), top = 4)
            }
        }
        add(body, stats)
        gap(body, 21)
        add(body, tv("RECEIPTS", 12f, muted, true), bottom = 10)
        val receipts = trip.receipts.sortedBy { it.sequence }
        if (receipts.isEmpty()) {
            val c = card()
            add(c, tv("Nothing recorded yet", 17f, navy, true))
            add(c, tv("Add your first expense. You'll be asked to take, choose, or skip a photo.",
                13f, muted), top = 7)
            add(body, c)
        }
        receipts.forEach { receipt ->
            val c = card()
            val content = row()
            val image = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                background = shape(pale, 9, line)
                if (receipt.imagePath.isNotBlank()) setThumb(this, receipt.imagePath)
                else setImageResource(android.R.drawable.ic_menu_gallery)
            }
            content.addView(image, LinearLayout.LayoutParams(dp(65), dp(65)))
            val textCol = column().apply { setPadding(dp(12), 0, 0, 0) }
            add(textCol, tv("#${receipt.ref}   ${receipt.place}", 15f, navy, true))
            add(textCol, tv("${receipt.category}  ·  ${receipt.date}", 11f, muted), top = 4)
            add(textCol, tv("${receipt.localCode} ${money(receipt.localValue())}     £${money(receipt.gbpValue())}",
                13f, teal, true), top = 6)
            content.addView(textCol, LinearLayout.LayoutParams(0, -2, 1f))
            c.addView(content)
            c.isClickable = true
            c.isFocusable = true
            c.setOnClickListener { renderEditor(id, receipt.id, false) }
            add(body, c, bottom = 10)
        }
        add(body, tv("Tap any receipt to edit its details or photo.", 12f, muted), top = 6)
        footer(root) { foot ->
            if (trip.endedAt == null) {
                add(foot, button("+  Add receipt") { renderEditor(id, null, true) })
                add(foot, button("End trip & export ZIP", false) { confirmEndTrip(trip) }, top = 9)
            } else {
                add(foot, button("Export ZIP again") { exportTrip(trip, false) })
                add(foot, button("Reopen trip", false) {
                    trip.endedAt = null
                    store.save()
                    renderTrip(id)
                }, top = 9)
            }
        }
    }

    private fun entry(hintText: String, initial: String, numeric: Boolean): EditText =
        EditText(this).apply {
            hint = hintText
            setText(initial)
            textSize = 15f
            setTextColor(navy)
            setHintTextColor(muted)
            isSingleLine = true
            setSelectAllOnFocus(false)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = shape(white, 12, line)
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or
                InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        }

    private fun labeled(parent: LinearLayout, label: String, field: View, top: Int = 15) {
        add(parent, tv(label, 11f, muted, true), top = top, bottom = 7)
        add(parent, field)
    }

    private fun renderEditor(tripKey: String, receiptKey: String?, prompt: Boolean) {
        val trip = store.get(tripKey) ?: return
        val saved = trip.receipts.firstOrNull { it.id == receiptKey }
        tripId = tripKey
        receiptId = receiptKey
        page = Page.EDIT
        photoPath = saved?.imagePath ?: ""
        originalPhotoName = saved?.originalImageName ?: ""
        val (root, body) = base(if (saved == null) "New receipt" else "Edit receipt #${saved.ref}",
            "Each amount is entered manually — no conversion.", { cancelEdit() })
        val photo = card()
        add(photo, tv("RECEIPT IMAGE  ·  OPTIONAL", 11f, muted, true))
        photoPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = shape(pale, 11, line)
        }
        val preview = photoPreview!!
        add(photo, preview, top = 12)
        preview.layoutParams.height = dp(142)
        photoCaption = tv("", 12f, muted)
        add(photo, photoCaption!!, top = 8)
        val photoButtons = row()
        val change = button("Choose / take photo", false) { photoPrompt(false) }
        photoButtons.addView(change, LinearLayout.LayoutParams(0, -2, 1f))
        val remove = tv("Remove", 13f, teal, true).apply {
            setPadding(dp(13), dp(14), dp(4), dp(14))
            isClickable = true
            setOnClickListener {
                photoPath = ""
                originalPhotoName = ""
                refreshPhoto()
            }
        }
        photoButtons.addView(remove)
        add(photo, photoButtons, top = 12)
        add(body, photo)
        refreshPhoto()

        val form = card()
        val place = entry("Where did you spend it?", saved?.place ?: "", false)
        labeled(form, "PLACE NAME", place, 0)

        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, categories)
            background = shape(white, 12, line)
            setPadding(dp(8), dp(7), dp(8), dp(7))
        }
        val idx = categories.indexOf(saved?.category)
        spinner.setSelection(if (idx < 0) categories.lastIndex else idx)
        labeled(form, "TYPE OF EXPENSE", spinner)
        val other = entry("Specify another category", if (idx < 0) saved?.category ?: "" else "", false)
        add(form, other, top = 8)
        other.visibility = if (spinner.selectedItemPosition == categories.lastIndex) View.VISIBLE else View.GONE
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, p: Int, id: Long) {
                other.visibility = if (p == categories.lastIndex) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }

        val code = entry("EUR / USD / JPY", saved?.localCode ?: trip.defaultCurrency, false)
        code.filters = arrayOf(android.text.InputFilter.LengthFilter(3))
        val local = entry("0.00", saved?.localAmount ?: "", true)
        val gbp = entry("0.00", saved?.gbpAmount ?: "", true)
        labeled(form, "LOCAL CURRENCY CODE", code)
        labeled(form, "COST IN LOCAL CURRENCY", local)
        labeled(form, "COST IN GBP (£) — ENTER MANUALLY", gbp)
        add(form, tv("GBP is never calculated from the local amount.", 12f, teal), top = 7)

        var chosenDate = saved?.date ?: LocalDate.now().format(dateFormat)
        val date = button("Date: $chosenDate", false) {}
        date.setOnClickListener {
            val initial = runCatching { LocalDate.parse(chosenDate) }.getOrDefault(LocalDate.now())
            DatePickerDialog(this, { _, y, m, d ->
                chosenDate = LocalDate.of(y, m + 1, d).format(dateFormat)
                date.text = "Date: $chosenDate"
            }, initial.year, initial.monthValue - 1, initial.dayOfMonth).show()
        }
        labeled(form, "EXPENSE DATE", date)
        val notes = entry("Optional description or reference", saved?.notes ?: "", false)
        labeled(form, "NOTES  ·  OPTIONAL", notes)
        add(body, form, top = 14)
        if (saved != null) {
            add(body, button("Delete this receipt", false) {
                AlertDialog.Builder(this).setTitle("Delete receipt #${saved.ref}?")
                    .setMessage("This will remove the expense and its stored image from the trip.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ ->
                        trip.receipts.removeAll { it.id == saved.id }
                        store.save()
                        if (saved.imagePath.isNotBlank()) File(saved.imagePath).delete()
                        renderTrip(tripKey)
                    }.show()
            }, top = 14)
        }

        footer(root) { foot ->
            add(foot, button("Save receipt") {
                val placeValue = place.text.toString().trim()
                val category = if (spinner.selectedItemPosition == categories.lastIndex)
                    other.text.toString().trim() else spinner.selectedItem.toString()
                val localCode = code.text.toString().trim().uppercase(Locale.ROOT)
                val a = parseAmount(local.text.toString())
                val b = parseAmount(gbp.text.toString())
                when {
                    placeValue.isBlank() -> { place.error = "Enter the place name"; place.requestFocus() }
                    category.isBlank() -> { other.error = "Enter an expense type"; other.requestFocus() }
                    !isCurrency(localCode) -> { code.error = "Enter a 3-letter code"; code.requestFocus() }
                    a == null -> { local.error = "Enter a valid amount"; local.requestFocus() }
                    b == null -> { gbp.error = "Enter GBP manually"; gbp.requestFocus() }
                    else -> {
                        val previousImage = saved?.imagePath ?: ""
                        if (saved == null) {
                            val r = Receipt(sequence = trip.nextSequence++, date = chosenDate,
                                place = placeValue, category = category, localCode = localCode,
                                localAmount = a.toPlainString(), gbpAmount = b.toPlainString(),
                                notes = notes.text.toString().trim(), imagePath = photoPath,
                                originalImageName = originalPhotoName)
                            trip.receipts.add(r)
                        } else {
                            saved.date = chosenDate
                            saved.place = placeValue
                            saved.category = category
                            saved.localCode = localCode
                            saved.localAmount = a.toPlainString()
                            saved.gbpAmount = b.toPlainString()
                            saved.notes = notes.text.toString().trim()
                            saved.imagePath = photoPath
                            saved.originalImageName = originalPhotoName
                        }
                        store.save()
                        if (previousImage.isNotBlank() && previousImage != photoPath) File(previousImage).delete()
                        renderTrip(tripKey)
                    }
                }
            })
        }
        if (prompt) root.post { if (page == Page.EDIT) photoPrompt(true) }
    }

    private fun parseAmount(raw: String): BigDecimal? {
        val value = raw.trim().replace(',', '.')
        if (value.isEmpty() || value.length > 32) return null
        return value.toBigDecimalOrNull()?.takeIf { it.scale() <= 4 && it.precision() <= 14 }
    }
    private fun isCurrency(s: String) = s.length == 3 && s.all { it in 'A'..'Z' }

    private fun photoPrompt(initial: Boolean) {
        AlertDialog.Builder(this)
            .setTitle(if (initial) "Add a receipt picture?" else "Receipt picture")
            .setItems(arrayOf("Take a photo", "Choose from gallery", "Skip picture")) { _, which ->
                when (which) {
                    0 -> takePicture()
                    1 -> pickPicture()
                    else -> { if (initial) { photoPath = ""; originalPhotoName = ""; refreshPhoto() } }
                }
            }.setCancelable(!initial).show()
    }

    private fun refreshPhoto() {
        val preview = photoPreview ?: return
        val caption = photoCaption ?: return
        val hasImage = photoPath.isNotBlank() && File(photoPath).exists()
        preview.visibility = if (hasImage) View.VISIBLE else View.GONE
        if (hasImage) {
            setThumb(preview, photoPath)
            caption.text = "Attached: $originalPhotoName"
        } else caption.text = "No image selected — you can save without one."
    }

    private fun setThumb(imageView: ImageView, path: String) {
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, opts)
            val maxDim = maxOf(opts.outWidth, opts.outHeight)
            val sample = (maxDim / 500).coerceAtLeast(1)
            val bitmap = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bitmap != null) imageView.setImageBitmap(bitmap)
            else imageView.setImageResource(android.R.drawable.ic_menu_gallery)
        } catch (_: Exception) {
            imageView.setImageResource(android.R.drawable.ic_menu_gallery)
        }
    }

    private fun pickPicture() {
        try {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }, REQUEST_GALLERY)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No image picker available", Toast.LENGTH_LONG).show()
        }
    }

    private fun takePicture() {
        val directory = File(filesDir, "images").apply { mkdirs() }
        val f = File(directory, "camera_${UUID.randomUUID()}.jpg")
        pendingCameraFile = f
        val uri = TripFileProvider.forFile("images", f.name)
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
            putExtra(MediaStore.EXTRA_OUTPUT, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            clipData = ClipData.newRawUri("Receipt photo", uri)
        }
        try { startActivityForResult(intent, REQUEST_CAMERA) }
        catch (_: ActivityNotFoundException) {
            pendingCameraFile = null
            Toast.makeText(this, "No camera app available", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses the platform activity-result API to support Android 8+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_GALLERY -> if (resultCode == RESULT_OK && data?.data != null) {
                try {
                    val uri = data.data!!
                    val name = queryName(uri).ifBlank { "receipt_${System.currentTimeMillis()}.jpg" }
                    val suffix = File(name).extension.lowercase().ifBlank { "jpg" }
                    val safeSuffix = suffix.takeIf { it.matches(Regex("[a-z0-9]{2,5}")) } ?: "jpg"
                    val f = File(File(filesDir, "images").apply { mkdirs() },
                        "picked_${UUID.randomUUID()}.$safeSuffix")
                    contentResolver.openInputStream(uri)?.use { source ->
                        f.outputStream().use { dest -> source.copyTo(dest) }
                    } ?: error("Could not open selected picture")
                    if (f.length() <= 0) error("Empty image")
                    photoPath = f.absolutePath
                    originalPhotoName = name
                    refreshPhoto()
                } catch (e: Exception) { errorDialog("Picture import failed", e.message ?: "Unknown error") }
            }
            REQUEST_CAMERA -> {
                val file = pendingCameraFile
                pendingCameraFile = null
                if (resultCode == RESULT_OK && file != null && file.length() > 0) {
                    photoPath = file.absolutePath
                    originalPhotoName = "receipt_${System.currentTimeMillis()}.jpg"
                    refreshPhoto()
                } else {
                    file?.delete()
                    if (resultCode == RESULT_OK) Toast.makeText(this, "The camera did not return a photo", Toast.LENGTH_LONG).show()
                }
            }
            REQUEST_SAVE_ZIP -> if (resultCode == RESULT_OK && data?.data != null) {
                val file = pendingExportFile ?: return
                try {
                    contentResolver.openOutputStream(data.data!!)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    } ?: error("Destination could not be opened")
                    Toast.makeText(this, "ZIP saved successfully", Toast.LENGTH_LONG).show()
                } catch (e: Exception) { errorDialog("Unable to save ZIP", e.message ?: "Unknown error") }
            }
        }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) return c.getString(0) ?: ""
        }
        return ""
    }

    private fun cancelEdit() {
        val original = store.get(tripId ?: "")?.receipts?.firstOrNull { it.id == receiptId }?.imagePath ?: ""
        if (photoPath.isNotBlank() && photoPath != original) File(photoPath).delete()
        renderTrip(tripId ?: return)
    }

    private fun confirmEndTrip(trip: Trip) {
        AlertDialog.Builder(this)
            .setTitle("End ${trip.title}?")
            .setMessage("The trip will be marked complete. We'll create an Excel workbook and numbered receipt photos in one ZIP. You can reopen and edit the trip later.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("End & export") { _, _ -> exportTrip(trip, true) }
            .show()
    }

    @Suppress("DEPRECATION")
    private fun exportTrip(trip: Trip, end: Boolean) {
        val oldEnded = trip.endedAt
        if (end) trip.endedAt = System.currentTimeMillis()
        val progress = ProgressDialog(this).apply {
            setTitle("Preparing ZIP")
            setMessage("Packaging spreadsheet and images…")
            setCancelable(false)
            show()
        }
        Thread {
            try {
                val zip = TripExporter.export(trip, File(filesDir, "exports"))
                runOnUiThread {
                    progress.dismiss()
                    if (end) store.save()
                    renderTrip(trip.id)
                    showExportOptions(zip)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.dismiss()
                    trip.endedAt = oldEnded
                    errorDialog("Export failed", e.message ?: "Unable to package this trip")
                }
            }
        }.start()
    }

    private fun showExportOptions(zip: File) {
        pendingExportFile = zip
        AlertDialog.Builder(this)
            .setTitle("Trip ZIP ready")
            .setMessage("Includes Expenses workbook, receipts/ images prefixed with their reference number, and a README. What would you like to do?")
            .setPositiveButton("Share") { _, _ -> shareZip(zip) }
            .setNeutralButton("Save ZIP") { _, _ -> saveZip(zip) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun shareZip(zip: File) {
        val uri = TripFileProvider.forFile("exports", zip.name)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/zip"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("Trip ZIP", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivity(Intent.createChooser(intent, "Share trip receipts")) }
        catch (e: ActivityNotFoundException) { errorDialog("Sharing unavailable", "No app can receive this ZIP") }
    }

    private fun saveZip(zip: File) {
        pendingExportFile = zip
        try {
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "application/zip"
                putExtra(Intent.EXTRA_TITLE, zip.name)
            }, REQUEST_SAVE_ZIP)
        } catch (_: ActivityNotFoundException) {
            errorDialog("Save unavailable", "No file picker is installed")
        }
    }

    private fun errorDialog(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when (page) {
            Page.EDIT -> cancelEdit()
            Page.TRIP -> renderTrips()
            Page.TRIPS -> super.onBackPressed()
        }
    }
}
