package uk.layerworks.tripreceipts

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.math.BigDecimal
import java.util.UUID

/** Local-only storage. All photos are copied into filesDir/images before being referenced. */
data class Receipt(
    val id: String = UUID.randomUUID().toString(),
    val sequence: Int,
    var date: String,
    var place: String,
    var category: String,
    var localCode: String,
    var localAmount: String,
    var gbpAmount: String,
    var notes: String = "",
    var imagePath: String = "",
    var originalImageName: String = ""
) {
    val ref: String get() = sequence.toString().padStart(2, '0')
    fun localValue(): BigDecimal = localAmount.toBigDecimalOrNull() ?: BigDecimal.ZERO
    fun gbpValue(): BigDecimal = gbpAmount.toBigDecimalOrNull() ?: BigDecimal.ZERO
}

data class Trip(
    val id: String = UUID.randomUUID().toString(),
    var title: String,
    var defaultCurrency: String,
    val createdAt: Long = System.currentTimeMillis(),
    var endedAt: Long? = null,
    var nextSequence: Int = 1,
    val receipts: MutableList<Receipt> = mutableListOf()
) {
    fun gbpTotal(): BigDecimal = receipts.fold(BigDecimal.ZERO) { sum, r -> sum + r.gbpValue() }
    fun localTotals(): Map<String, BigDecimal> = receipts.groupBy { it.localCode }
        .mapValues { (_, rs) -> rs.fold(BigDecimal.ZERO) { sum, r -> sum + r.localValue() } }
}

class TripStore(context: Context) {
    private val path = File(context.filesDir, "trips.json")
    val trips: MutableList<Trip> = mutableListOf()

    init { load() }

    fun get(id: String): Trip? = trips.firstOrNull { it.id == id }

    private fun load() {
        if (!path.exists()) return
        try {
            val arr = JSONArray(path.readText(Charsets.UTF_8))
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                val receiptArray = t.optJSONArray("receipts") ?: JSONArray()
                val receipts = mutableListOf<Receipt>()
                for (j in 0 until receiptArray.length()) {
                    val r = receiptArray.getJSONObject(j)
                    receipts.add(Receipt(
                        id = r.getString("id"),
                        sequence = r.getInt("sequence"),
                        date = r.optString("date"),
                        place = r.optString("place"),
                        category = r.optString("category"),
                        localCode = r.optString("localCode", "EUR"),
                        localAmount = r.optString("localAmount", "0"),
                        gbpAmount = r.optString("gbpAmount", "0"),
                        notes = r.optString("notes"),
                        imagePath = r.optString("imagePath"),
                        originalImageName = r.optString("originalImageName")
                    ))
                }
                trips.add(Trip(
                    id = t.getString("id"),
                    title = t.optString("title", "Untitled trip"),
                    defaultCurrency = t.optString("defaultCurrency", "EUR"),
                    createdAt = t.optLong("createdAt", System.currentTimeMillis()),
                    endedAt = if (t.isNull("endedAt")) null else t.optLong("endedAt"),
                    nextSequence = t.optInt("nextSequence", (receipts.maxOfOrNull { it.sequence } ?: 0) + 1),
                    receipts = receipts
                ))
            }
        } catch (e: Exception) {
            // Preserve any damaged database rather than silently overwrite it.
            throw IllegalStateException("Could not read trips.json. Original data was preserved.", e)
        }
    }

    fun save() {
        val arr = JSONArray()
        trips.forEach { trip ->
            val t = JSONObject()
            t.put("id", trip.id)
            t.put("title", trip.title)
            t.put("defaultCurrency", trip.defaultCurrency)
            t.put("createdAt", trip.createdAt)
            t.put("endedAt", trip.endedAt ?: JSONObject.NULL)
            t.put("nextSequence", trip.nextSequence)
            val rs = JSONArray()
            trip.receipts.forEach { r ->
                val obj = JSONObject()
                obj.put("id", r.id)
                obj.put("sequence", r.sequence)
                obj.put("date", r.date)
                obj.put("place", r.place)
                obj.put("category", r.category)
                obj.put("localCode", r.localCode)
                obj.put("localAmount", r.localAmount)
                obj.put("gbpAmount", r.gbpAmount)
                obj.put("notes", r.notes)
                obj.put("imagePath", r.imagePath)
                obj.put("originalImageName", r.originalImageName)
                rs.put(obj)
            }
            t.put("receipts", rs)
            arr.put(t)
        }
        val tmp = File(path.parentFile, "trips.json.tmp")
        tmp.writeText(arr.toString(2), Charsets.UTF_8)
        if (!tmp.renameTo(path)) {
            // File.renameTo on Linux/Android replaces the existing file atomically.
            throw IllegalStateException("Unable to save trips database")
        }
    }
}
